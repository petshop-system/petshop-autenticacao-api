package com.petshop.petshopautenticacaoapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetshopAutenticacaoApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
