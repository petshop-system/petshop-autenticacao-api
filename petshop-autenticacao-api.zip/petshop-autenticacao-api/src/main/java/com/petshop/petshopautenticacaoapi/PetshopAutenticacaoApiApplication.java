package com.petshop.petshopautenticacaoapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetshopAutenticacaoApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetshopAutenticacaoApiApplication.class, args);
	}

}
